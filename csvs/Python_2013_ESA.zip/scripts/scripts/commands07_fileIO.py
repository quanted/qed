#Slide 5
# file = open('myFileName.txt')
# print file

# for line in file:
#     print(line)   # line is a string, lets print it!
# file.close()

# print file


#Slide 6
# file = open('myFileName.txt')
# for line in file:
# 	for word in line.split(' '):
# 		print(word)		# lets print each word!
# file.close()

#Slide 7
# file = open('anotherFile.txt', 'w')
# file.write('This is output!\n')
# file.close()

#Slide 9
# file = open('anotherFile.txt', 'a')
# file.write('This is another output!\n')
# file.close()