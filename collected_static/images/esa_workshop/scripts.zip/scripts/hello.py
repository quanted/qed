# save this in a text file as hello.py
print "Hello Portland!"
# then navigate to its directory in a shell
# and run at the command prompt with 
# python hello.py