'''
Created on Aug 12, 2010

@author: pascact1
'''

class CardGame:

    def __init__(self):
        self.deck = Deck()
        self.deck.shuffle()
