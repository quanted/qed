# basic approach
def some_function(arg1, arg2):
  #some statements
  return answer

#doc_strings
def add_two_numbers(num1, num2):
  """ this function adds two numbers
  together"""
  return num1 + num2

# argument types
def double_it(required1, keyword2=2):
  return num1 * num2

double_it(6)
double_it(6,3) #actually triples it
