1 Read a file
1.1 Read StateoftheUnion.txt
    1.2 Output each word on its own line

2 Sum a file
2.1 Read IntegerFile.txt, which has many numbers on one line.
2.2 Calculate the sum, and the mean. Hint, the int() function
turns a string into a number.

3 File copier
3.1 Copy http://www.ubertool.org/index.html to a file on your local disk.
