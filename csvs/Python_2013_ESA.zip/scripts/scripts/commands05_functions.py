def some_function ( arg1 , arg2 ) :
    #some statements
    return answer

def add_two_numbers(num1, num2):
    return num1 + num2

def add_two_numbers(num1, num2):
    """ this function adds two
    numbers together"""
    return num1 + num2

def double_it ( required1 , keyword2=2):
    return required1 * keyword2
